# Blank handler used to create successful deployment
def handle(event, context):
    print("Handling")
    return "Finished"